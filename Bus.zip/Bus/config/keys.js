module.exports={
  MongoURI:'mongodb+srv://rishav:12345@cluster0-yhc4p.mongodb.net/test?retryWrites=true&w=majority'
}

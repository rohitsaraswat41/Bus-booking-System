# BusBooking
I created this website in nodejs reactjs mongodb and express

user can find the buses from origin to destination 
user can select the number of seats and fill the details of pessanger and print the ticket
